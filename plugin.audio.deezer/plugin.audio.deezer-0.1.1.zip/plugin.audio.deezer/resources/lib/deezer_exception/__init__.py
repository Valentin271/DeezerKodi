"""
This package contains all the differents Exceptions of the DeezerKodi addon.
"""

from deezer_exception import DeezerException
from quota_exception import QuotaException
