from deezer_api import *


connection = Connection('famille.doreau@outlook.fr', 'p0uc3tt3.77')
api = Api(connection)
