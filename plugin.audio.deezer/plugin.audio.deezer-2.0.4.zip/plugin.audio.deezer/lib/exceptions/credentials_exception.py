from .deezerkodi_exception import DeezerKodiException


class CredentialsException(DeezerKodiException):
    """Exception thrown when user credentials are not present"""
