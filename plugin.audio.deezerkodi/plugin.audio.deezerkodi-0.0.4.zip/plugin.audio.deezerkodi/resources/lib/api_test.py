#!/usr/bin/env python3

import DeezerApi as dzapi

con = dzapi.Connection('famille.doreau@outlook.fr', 'p0uc3tt3.77'.encode())

import pdb; pdb.set_trace()